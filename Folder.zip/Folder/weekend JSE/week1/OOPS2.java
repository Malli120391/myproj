/*OOPS techin2 */
/*
note:
=====
 when we are using class , then class is providing bothe encapsulation 
 and abstraction 
 for all project memebers, then there is no exaclty specification ..,
 but in developement client need specifications..

 to fulfille the above client requiremens, 
 then as a developer manuvally we have to maintain class of 
 encapsulation and 
 abstraction with the help of "access modifier" are

 -> private
 -> public 
 -> protected
 -> default


about  -> private
===============
 using this we can acess and implements class of memebres with in 
 the class only(complete encapsulation)

about-> public 
============
 using this we can can access and implements class of mebers with in 
 the class, out side of class and out side of 
 the package also.(complete abstraction)..

about -> protected:
===============
 using this we can access and implements class of memebers with 
 the class  and out side of the class , 
 but not outside of the packages..(partial abstraction)

about -> default:
=============
 when we are using not using any acces modifier, 
 then JVM consider like default..

 => here deault functionalaties similar to protected...

Q: what is DE b/w default and protected..?
  ans:
  protected pshycially existed..
  default pshycially not existed..

 
ex:
===

*/
 import java.util.Scanner;

class Employee
 {
private String  id;  // requirements
private String name;
private double sal;
private int age;


public void reading()
 {
Scanner sc=new Scanner(System.in);

System.out.println(" enter id in String format:");
id=sc.next();
 
System.out.println(" enter name in String name:");
name=sc.next();

System.out.println(" enter sal in double sal:");
sal=sc.nextDouble();

System.out.println(" enter age in int age:");
age=sc.nextInt();

 }
public void details() // implementaion
 {
 System.out.println(" emp DETIALS");
 System.out.println(" ===============");
 System.out.println(" emp id is        :"+id);
 System.out.println(" emp name is  :"+name);
 System.out.println(" emp salary is :"+sal);
 System.out.println(" emp age  is    :"+age);

 }
 
 }// closing app


class OOPS2
 {
   public static void main(String[]args)
  {
Employee e=new Employee();
 e.reading();
  e.details(); 
  }
 }

 /*

note:
=====
  assigning values to the variable we have 2 approches..
  1. compiler time(before compiling the application , 
  then direclty we are fixing values to the variable);

ex:
 int age=10;
 String name="raju";
 
2. runtime(everytime values are taking at runtime..so 
   that before compilation  , 
   then just keep empty variable)..

ex:

 int age;
 String name;

========================================
  in java to read values at runtime , then we have 3 syntax's

1. using Scanner class of methods
2. using BufferedReader class of methods
3. using command line arguments..


 Working with Scanner class of method to read values 
 from keyboard(System.in) at runtime
=====================================
 req        Scanner class of method
----          ------------------------------
byte          -> nextByte();
short         -> nextShort();
int           -> nextInt();
long      --> nextLong();
float      --> nextFloat();
double  ----> nextDouble();
char        -> next(); -> String
boolean  --> nextBoolean();

note: to call the above methods from Scanner , 
then we have create object to "Scanner" class

ex: 
 */