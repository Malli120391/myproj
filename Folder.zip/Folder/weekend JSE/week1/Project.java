 /*  Working with OOS basics  */

 //   OOPS Techinc-1

class App1
 {
 int a=10;

  void task1()
  {
  System.out.println("a value is :"+a);
  }
 }// closing App1


class App2
 {
 int b=20;

  void task2()
  {
  System.out.println("b value is :"+b);
  }
 }// closing App2

class App3
 {
 int c=30;

  void task3()
  {
  System.out.println("c value is :"+c);
  }
 }// closing App3



class Project
 {
   public static void main(String[]args)
   {

  App1 a1=new App1();
 a1.task1();

  App2 a2=new App2();
 a2.task2();

  App3 a3=new App3();
 a3.task3();

   }

 }

// DEveloper obj
 
according to the above example i understood ..
how do i execute mulitple class's at a time by writing 
one saparate class for main method.. 
and inside of main method will  keep all class of instance(object),,



