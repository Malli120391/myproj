/* first java  of JSE programme  */

 class FirstJavaApp 
 {

int a=10;  //  requirements 
int b=20;
int c;


void add() //  implementations
  {
   c=a+b;
System.out.println("ur add values is: "+c);
  }

 void sub()
 {
  c=a-b; // logics
System.out.println("ur sub values is: "+c);

 }
 void task()
  {
 c= a>b ? a:b; // logics
System.out.println("ur greteste  values is: "+c);

  }

public static void main(String[]args) // JVM refernce
  { 
 // execution part
FirstJavaApp f=new FirstJavaApp();

f.add();
f.sub();
f.task();
  }
 }// closing app



/* flow of execution
----------------------------
 JVM -> main -> object -> class of member
*/



/*
Q: how JVM will execute JSE project..?

  ans : throgh "public static void main(String[]args)"

*/


/*
in java we have 3 modules

1-> JSE(java standared edition)
============================
  using this we can develope standalone(single user) application .. 
which are executing from local system..

ex:organization DB's project, entivirus & all desktop applications

 note: it is providing java rules and guidelined for other modules refernce's..
 so that we can call it java fixed edition




2-> JEE(java enterprise edition
 ===========================
  using this we can develope enterprise(multi user) applications.. 
which are execution from server..

ex: all internet application..


3-> JME(java micro edition)
=========================
 using this we can develope mobile applications...
ex: all mobile applications



*/


/*

// printing only statement uisng S.O.P

System.out.println("WELCOME TO JAVA");
System.out.println("==============");

// pringint variable data

System.out.println(a);
System.out.println(b);
System.out.println(c);

// printing statement and variable with single SOP

System.out.println("a value is :",a); // error
System.out.println("a value is :"+a); // valid

System.out.println(b+"output"); // valid

//printing multiple variable with single sop

System.out.println(a,b,c); // error
System.out.println(a+b+c); // addition

System.out.println(a+":::"+b+":::"+c); // valid


// printing mulitple ststement with single sop

System.out.println("hai"+"hello"+"bye"); // valid
  
 output: hai hello bye

System.out.println("\n hai"+" \n hello"+" \n bye");

output:
 hai
 hello 
bye

ecape sequnce:
-------------------------
\n-> next line
\t-> tab space
\b->back space
\a->alet bell

 */







